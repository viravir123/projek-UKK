<?php
session_start();
include "service/database.php";

$total_buku = 0;
$total_dipinjam = 0;

/* =======================
   CEK LOGIN
======================= */
if(!isset($_SESSION["is_login"])){
    header("location: index.php");
    exit();
}

/* =======================
   TOTAL BUKU
======================= */
$jumlah = $db->query("SELECT COUNT(*) AS total FROM buku");
if($jumlah){
    $row = $jumlah->fetch_assoc();
    $total_buku = $row['total'];
}

/* =======================
   TOTAL BUKU DIPINJAM
======================= */
$jumlah_pinjam = $db->query("SELECT COUNT(*) AS total FROM peminjaman WHERE status='dipinjam'");
if($jumlah_pinjam){
    $row_pinjam = $jumlah_pinjam->fetch_assoc();
    $total_dipinjam = $row_pinjam['total'];
}

/* LOGOUT */
if(isset($_POST['logout'])){
    session_unset();
    session_destroy();
    header('location: index.php');
    exit();
}

/* SEARCH */
$keyword = $_GET['search'] ?? '';

$buku = [];

if($keyword != ''){
    $sql = "SELECT * FROM buku 
            WHERE judul LIKE '%$keyword%' 
            OR penulis LIKE '%$keyword%' 
            ORDER BY id_buku DESC";
} else {
    $sql = "SELECT * FROM buku ORDER BY id_buku DESC LIMIT 8";
}

$result = $db->query($sql);

if($result){
    while($row = $result->fetch_assoc()){
        $buku[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Dashboard User</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', sans-serif;
    background:#FFFACD;
    display:flex;
}

/* SIDEBAR */
.sidebar{
    width:230px;
    min-height:100vh;
    background:#FFF8DC;
    padding:20px;
    box-shadow:2px 0 10px rgba(0,0,0,0.1);
    position:relative;
}

.sidebar h3{
    text-align:center;
    color:#8B8000;
}

.sidebar a{
    display:block;
    padding:12px;
    margin-top:10px;
    text-decoration:none;
    color:#333;
    border-radius:8px;
}

.sidebar a:hover{
    background:#FFD700;
}

/* LOGOUT */
.logout-btn{
    position:absolute;
    bottom:20px;
    left:20px;
    right:20px;
    background:#F08080;
    color:white;
    text-align:center;
    padding:12px;
    border-radius:8px;
    cursor:pointer;
}

/* MAIN */
.main{
    flex:1;
}

/* NAVBAR */
.navbar{
    background:#FFF8DC;
    padding:15px 25px;
}

/* SEARCH */
.search-box{
    padding:0 20px;
}

.search-box input{
    padding:10px;
    border-radius:8px;
    border:1px solid #ccc;
}

.search-box button{
    padding:10px;
    background:#FFD700;
    border:none;
    border-radius:8px;
}

/* BOX STATISTIK */
.box-wrap{
    display:flex;
    gap:15px;
    margin:20px;
}

.box{
    padding:20px;
    width:220px;
    color:white;
    border-radius:12px;
    box-shadow:0 6px 15px rgba(0,0,0,0.2);
}

/* GRID */
.container{
    padding:20px;
    display:grid;
    grid-template-columns:repeat(8,1fr);
    gap:15px;
}

/* CARD */
.card{
    background:#FFF8DC;
    padding:12px;
    border-radius:10px;
    min-height:280px;
    display:flex;
    flex-direction:column;
    justify-content:space-between;
}

.card img{
    width:100%;
    height:200px;
    object-fit:cover;
    border-radius:8px;
}

.detail-btn{
    display:inline-block;
    margin-top:5px;
    background:#FFD700;
    padding:5px 8px;
    border-radius:6px;
    text-decoration:none;
    font-size:12px;
}

/* MODAL */
.modal{
    display:none;
    position:fixed;
    top:0;left:0;
    width:100%;height:100%;
    background:rgba(0,0,0,0.5);
    justify-content:center;
    align-items:center;
}

.modal-content{
    background:white;
    width:420px;
    padding:30px;
    border-radius:15px;
    text-align:center;
}

.btn-group{
    display:flex;
    gap:10px;
    margin-top:20px;
}

.btn-yes{
    flex:1;
    background:#e74c3c;
    color:white;
    padding:10px;
    border:none;
    border-radius:8px;
}

.btn-no{
    flex:1;
    background:#2ecc71;
    color:white;
    padding:10px;
    border:none;
    border-radius:8px;
}
</style>
</head>

<body>

<!-- SIDEBAR -->
<div class="sidebar">
    <h3>Menu</h3>

    <a href="dashboard.php">Dashboard</a>
    <a href="riwayat_user.php">Riwayat</a>

    <div class="logout-btn" onclick="openModal()">Logout</div>
</div>

<!-- MAIN -->
<div class="main">

<div class="navbar">
    <h2>Perpustakaan</h2>
</div>

<!-- BOX STATISTIK -->
<div class="box-wrap">

    <div class="box" style="background:linear-gradient(135deg,#FFD700,#FFA500);">
        <h4>Total Buku</h4>
        <h2><?= $total_buku ?></h2>
    </div>

    <div class="box" style="background:linear-gradient(135deg,#00c6ff,#0072ff);">
        <h4>Buku Dipinjam</h4>
        <h2><?= $total_dipinjam ?></h2>
    </div>

</div>

<!-- SEARCH -->
<div class="search-box">
<form method="GET">
    <input type="text" name="search" value="<?= $keyword ?>" placeholder="Cari buku...">
    <button>Cari</button>
</form>
</div>

<!-- GRID -->
<div class="container">

<?php foreach($buku as $item): ?>

<div class="card">

<?php if(!empty($item['foto'])): ?>
    <img src="upload/<?= $item['foto'] ?>">
<?php else: ?>
    <div style="height:140px;background:#ddd;display:flex;align-items:center;justify-content:center;">
        No Image
    </div>
<?php endif; ?>

<h4><?= $item['judul'] ?></h4>
<small><?= $item['penulis'] ?></small>

<a class="detail-btn" href="detail_buku.php?id=<?= $item['id_buku'] ?>">
Detail
</a>

</div>

<?php endforeach; ?>

</div>

</div>

<!-- MODAL LOGOUT -->
<div class="modal" id="modal">
    <div class="modal-content">
        <h3>Konfirmasi Logout</h3>
        <p>Yakin mau keluar?</p>

        <div class="btn-group">
            <form method="POST" style="flex:1;">
                <button name="logout" class="btn-yes">Ya Logout</button>
            </form>

            <button class="btn-no" onclick="closeModal()">Batal</button>
        </div>
    </div>
</div>

<script>
function openModal(){
    document.getElementById('modal').style.display='flex';
}
function closeModal(){
    document.getElementById('modal').style.display='none';
}
</script>

</body>
</html>