<?php
session_start();
include "service/database.php";

/* =========================
   CEK LOGIN & ROLE
========================= */
if(!isset($_SESSION["is_login"])){
    header("location: index.php");
    exit();
}

if($_SESSION['role'] != 'admin'){
    header("location: dashboard.php");
    exit();
}

/* =========================
   KONFIRMASI PINJAM
   pending -> dipinjam
   set tanggal_pinjam otomatis
========================= */
if(isset($_GET['konfirmasi'])){

    $id = (int) $_GET['konfirmasi'];

    $data = $db->query("SELECT * FROM peminjaman WHERE id_peminjaman='$id'")->fetch_assoc();

    if($data && $data['status'] == 'pending'){

        $db->query("UPDATE peminjaman 
                    SET status='dipinjam',
                        tanggal_pinjam = NOW()
                    WHERE id_peminjaman='$id'");
    }

    header("location: data_peminjaman.php");
    exit();
}

/* =========================
   PENGEMBALIAN BUKU
   dipinjam -> dikembalikan
   set tanggal_kembali otomatis
   + tambah stok buku
========================= */
if(isset($_GET['kembali'])){

    $id = (int) $_GET['kembali'];

    $data = $db->query("SELECT * FROM peminjaman WHERE id_peminjaman='$id'")->fetch_assoc();

    if($data && $data['status'] == 'dipinjam'){

        $db->query("UPDATE peminjaman 
                    SET status='dikembalikan',
                        tanggal_kembali = NOW()
                    WHERE id_peminjaman='$id'");

        $db->query("UPDATE buku 
                    SET stok = stok + 1 
                    WHERE id_buku='".$data['id_buku']."'");
    }

    header("location: data_peminjaman.php");
    exit();
}

/* =========================
   AMBIL DATA PEMINJAMAN
========================= */
$peminjaman = [];

$cari = $_GET['cari'] ?? '';

if(!empty($cari)){
    $cari = $db->real_escape_string($cari);

    $sql = "SELECT peminjaman.*, user.nama_lengkap, buku.judul
            FROM peminjaman
            LEFT JOIN user ON peminjaman.id_user = user.id_user
            LEFT JOIN buku ON peminjaman.id_buku = buku.id_buku
            WHERE user.nama_lengkap LIKE '%$cari%'
            OR buku.judul LIKE '%$cari%'
            OR peminjaman.status LIKE '%$cari%'
            ORDER BY peminjaman.id_peminjaman DESC";
} else {
    $sql = "SELECT peminjaman.*, user.nama_lengkap, buku.judul
            FROM peminjaman
            LEFT JOIN user ON peminjaman.id_user = user.id_user
            LEFT JOIN buku ON peminjaman.id_buku = buku.id_buku
            ORDER BY peminjaman.id_peminjaman DESC";
}

$result = $db->query($sql);

while($row = $result->fetch_assoc()){
    $peminjaman[] = $row;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Data Peminjaman</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', sans-serif;
    background:#FFFACD;
}

.header{
    background:#FFF8DC;
    color:#8B8000;
    padding:15px 25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 2px 8px rgba(0,0,0,0.08);
}

.header a{
    color:#333;
    text-decoration:none;
    background:#FFD700;
    padding:8px 12px;
    border-radius:8px;
}

.container{
    padding:25px;
}

.table-box{
    background:#FFF8DC;
    padding:20px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.1);
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
}

th{
    background:#FFD700;
    color:#333;
    padding:12px;
}

td{
    padding:12px;
    text-align:center;
    border-bottom:1px solid #eee;
}

tr:hover{
    background:#fff9e6;
}

.badge-pending{background:#f1c40f;padding:5px 10px;border-radius:6px;}
.badge-dipinjam{background:#f4b183;color:#fff;padding:5px 10px;border-radius:6px;}
.badge-kembali{background:#a9dfbf;padding:5px 10px;border-radius:6px;}

.btn{
    padding:6px 10px;
    border-radius:6px;
    text-decoration:none;
    font-size:12px;
}

.btn-konfirmasi{background:#3498db;color:white;}
.btn-kembali{background:#FFD700;color:#333;}

.empty{text-align:center;padding:20px;color:#777;}
</style>

</head>
<body>

<div class="header">
    <h3>Data Peminjaman Buku</h3>
    <a href="dashboard_admin.php">← Kembali</a>
</div>

<div class="container">
<div class="table-box">

<form method="GET" style="margin-bottom:15px;display:flex;gap:10px;">
    <input type="text" name="cari" placeholder="Cari..." value="<?= $_GET['cari'] ?? '' ?>"
    style="padding:10px;width:250px;border-radius:8px;border:1px solid #ccc;">

    <button style="padding:10px 15px;border:none;border-radius:8px;background:#3498db;color:white;">
        Cari
    </button>

    <a href="data_peminjaman.php" style="padding:10px 15px;background:#aaa;color:white;border-radius:8px;text-decoration:none;">
        Reset
    </a>
</form>

<?php if(count($peminjaman) > 0): ?>

<table>
<tr>
    <th>No</th>
    <th>Nama</th>
    <th>Buku</th>
    <th>Tgl Pinjam</th>
    <th>Tgl Kembali</th>
    <th>Status</th>
    <th>Aksi</th>
</tr>

<?php $no=1; foreach($peminjaman as $item): ?>
<tr>
    <td><?= $no++ ?></td>
    <td><?= $item['nama_lengkap'] ?></td>
    <td><?= $item['judul'] ?></td>

    <td><?= $item['tanggal_pinjam'] ? date('d-m-Y H:i',strtotime($item['tanggal_pinjam'])) : '-' ?></td>
    <td><?= $item['tanggal_kembali'] ? date('d-m-Y H:i',strtotime($item['tanggal_kembali'])) : '-' ?></td>

    <td>
        <?php if($item['status']=='pending'): ?>
            <span class="badge-pending">Pending</span>
        <?php elseif($item['status']=='dipinjam'): ?>
            <span class="badge-dipinjam">Dipinjam</span>
        <?php else: ?>
            <span class="badge-kembali">Selesai</span>
        <?php endif; ?>
    </td>

    <td>
        <?php if($item['status']=='pending'): ?>
            <a class="btn btn-konfirmasi" href="data_peminjaman.php?konfirmasi=<?= $item['id_peminjaman'] ?>">Konfirmasi</a>

        <?php elseif($item['status']=='dipinjam'): ?>
            <a class="btn btn-kembali" href="data_peminjaman.php?kembali=<?= $item['id_peminjaman'] ?>"
               onclick="return confirm('Kembalikan buku?')">Kembalikan</a>

        <?php else: ?>
            -
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; ?>
</table>

<?php else: ?>
<div class="empty">Belum ada data peminjaman</div>
<?php endif; ?>

</div>
</div>

</body>
</html>
