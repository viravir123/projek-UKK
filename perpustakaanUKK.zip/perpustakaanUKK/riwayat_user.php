<?php
session_start();
include "service/database.php";

if(!isset($_SESSION["is_login"])){
    header("location: index.php");
    exit();
}

$id_user = $_SESSION['id_user'];
$riwayat = [];

// QUERY
$stmt = $db->prepare("
    SELECT peminjaman.*, user.nama_lengkap, buku.judul, buku.penulis
    FROM peminjaman
    LEFT JOIN user ON peminjaman.id_user = user.id_user
    LEFT JOIN buku ON peminjaman.id_buku = buku.id_buku
    WHERE peminjaman.id_user = ?
    ORDER BY id_peminjaman DESC
");

if(!$stmt){
    die("Query error: " . $db->error);
}

$stmt->bind_param("i", $id_user);
$stmt->execute();
$result = $stmt->get_result();

while($row = $result->fetch_assoc()){
    $riwayat[] = $row;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Riwayat Peminjaman</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

body{
    background:#FFFACD;
    min-height:100vh;
}

.box{
    width:95%;
    max-width:1200px;
    margin:30px auto;
    background:#FFF8DC;
    border-radius:20px;
    padding:30px;
    box-shadow:0 10px 25px rgba(0,0,0,0.1);
}

h3{
    text-align:center;
    color:#8B8000;
    margin-bottom:20px;
    font-size:28px;
}

a.back{
    display:inline-block;
    margin-bottom:20px;
    padding:10px 15px;
    background:#FFD700;
    color:#333;
    text-decoration:none;
    border-radius:8px;
}

a.back:hover{
    background:#f1c40f;
}

table{
    width:100%;
    border-collapse:collapse;
}

th{
    background:#FFD700;
    padding:12px;
}

td{
    padding:12px;
    text-align:center;
    border-bottom:1px solid #eee;
}

tr:hover{
    background:#fff9e6;
}

/* BADGE */
.badge-pending{
    background:#f1c40f;
    padding:5px 10px;
    border-radius:6px;
}

.badge-dipinjam{
    background:#f4b183;
    color:white;
    padding:5px 10px;
    border-radius:6px;
}

.badge-kembali{
    background:#a9dfbf;
    padding:5px 10px;
    border-radius:6px;
}

.empty{
    text-align:center;
    padding:30px;
    color:#777;
}
</style>
</head>

<body>

<div class="box">

<h3>Riwayat Peminjaman Saya</h3>

<a href="dashboard.php" class="back">⬅ Kembali</a>

<?php if(count($riwayat) > 0): ?>

<table>
<tr>
    <th>No</th>
    <th>Judul</th>
    <th>Penulis</th>
    <th>Tanggal Pinjam</th>
    <th>Tanggal Kembali</th>
    <th>Status</th>
</tr>

<?php $no = 1; ?>
<?php foreach($riwayat as $item): ?>

<?php 
$status = strtolower(trim($item['status']));
?>

<tr>
    <td><?= $no++ ?></td>
    <td><?= $item['judul'] ?></td>
    <td><?= $item['penulis'] ?></td>

    <!-- TANGGAL PINJAM -->
    <td>
        <?= !empty($item['tanggal_pinjam']) 
            ? date('d-m-Y H:i', strtotime($item['tanggal_pinjam'])) 
            : '-' ?>
    </td>

    <!-- TANGGAL KEMBALI -->
    <td>
        <?= ($status == 'dikembalikan' && !empty($item['tanggal_kembali']))
            ? date('d-m-Y H:i', strtotime($item['tanggal_kembali']))
            : '-' ?>
    </td>

    <!-- STATUS -->
    <td>
        <?php if($status == 'pending'): ?>
            <span class="badge-pending">Menunggu Konfirmasi</span>

        <?php elseif($status == 'dipinjam'): ?>
            <span class="badge-dipinjam">Dipinjam</span>

        <?php elseif($status == 'dikembalikan'): ?>
            <span class="badge-kembali">Dikembalikan</span>

        <?php else: ?>
            <span>-</span>
        <?php endif; ?>
    </td>

</tr>

<?php endforeach; ?>
</table>

<?php else: ?>

<div class="empty">
    Belum ada riwayat peminjaman
</div>

<?php endif; ?>

</div>

</body>
</html>