<?php
session_start();

// biar session bersih
session_unset();
session_destroy();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>aplikasi peminjaman buku Ceria</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

/* 🌼 BACKGROUND KUNING LEMBUT */
body{
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background: linear-gradient(135deg, #FFFFE0, #FFFACD);
}

/* 🔥 BOX BESAR & LEBIH SOFT */
.box{
    width:600px;
    padding:70px;
    border-radius:25px;
    text-align:center;

    background: rgba(255,255,255,0.7);
    backdrop-filter: blur(10px);

    box-shadow:0 15px 40px rgba(0,0,0,0.2);
    border:1px solid rgba(255,255,255,0.5);

    color:#444;
    transition:0.3s;
}

.box:hover{
    transform:scale(1.02);
}

/* TITLE */
.box h1{
    font-size:36px;
    margin-bottom:15px;
    color:#b8860b; /* golden tone */
}

/* DESKRIPSI */
.box p{
    font-size:16px;
    margin-bottom:35px;
}

/* BUTTON */
.btn{
    display:block;
    padding:16px;
    margin:15px 0;
    border-radius:14px;
    text-decoration:none;
    color:white;
    font-weight:bold;
    font-size:16px;
    transition:0.3s;
}

/* 🎨 BUTTON WARNA SERASI */
.login{
    background:#f4b400; /* kuning hangat */
}

.register{
    background:#ff9800; /* oranye lembut */
}

/* HOVER */
.btn:hover{
    transform:scale(1.05);
    opacity:0.9;
}

/* RESPONSIVE */
@media(max-width:768px){
    .box{
        width:90%;
        padding:40px;
    }
}
</style>
</head>

<body>

<div class="box">
    <h1>aplikasi peminjaman buku Ceria </h1>
    <p>Membaca buku itu seperti membuka pintu ke dunia yang tenang dan penuh makna, di setiap halamannya tersimpan cerita, ilmu, dan perasaan yang bisa membuat hati lebih luas, pikiran lebih jernih, dan hidup terasa lebih berwarna tanpa harus pergi ke mana pun.</p>

    <a href="login.php" class="btn login">Login</a>
    <a href="register.php" class="btn register">Register</a>
</div>

</body>
</html>