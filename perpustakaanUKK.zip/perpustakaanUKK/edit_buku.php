<?php
session_start();
include "service/database.php";

if(!isset($_SESSION["is_login"])){
    header("location: index.php");
    exit();
}

$id = $_GET['id'] ?? 0;

/* AMBIL DATA */
$buku = $db->query("SELECT * FROM buku WHERE id_buku='$id'")->fetch_assoc();

if(!$buku){
    die("Buku tidak ditemukan");
}

$message = "";

/* UPDATE */
if(isset($_POST['update'])){

    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $deskripsi = $_POST['deskripsi'];
    $stok = $_POST['stok'];
    $kategori = $_POST['kategori'];

    $nama_file = $_FILES['foto']['name'];
    $tmp_file = $_FILES['foto']['tmp_name'];

    if(!empty($nama_file)){
        move_uploaded_file($tmp_file, "upload/".$nama_file);

        $sql = "UPDATE buku SET 
                judul='$judul',
                penulis='$penulis',
                deskripsi='$deskripsi',
                stok='$stok',
                kategori='$kategori',
                foto='$nama_file'
                WHERE id_buku='$id'";
    } else {
        $sql = "UPDATE buku SET 
                judul='$judul',
                penulis='$penulis',
                deskripsi='$deskripsi',
                stok='$stok',
                kategori='$kategori'
                WHERE id_buku='$id'";
    }

    if($db->query($sql)){
        $message = "Buku berhasil diupdate";
        $buku = $db->query("SELECT * FROM buku WHERE id_buku='$id'")->fetch_assoc();
    } else {
        $message = "Gagal update";
    }
}

/* DELETE */
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Edit Buku</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', sans-serif;
    background:#FFFACD; /* lemon chiffon */
}

/* CENTER */
.container{
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
    padding:20px;
}

/* CARD */
.card{
    background:#FFF8DC; /* light yellow */
    width:85%;
    max-width:950px;
    padding:40px;
    border-radius:20px;
    box-shadow:0 10px 25px rgba(0,0,0,0.1);
}

/* TITLE */
h2{
    text-align:center;
    margin-bottom:20px;
    color:#8B8000;
}

/* MESSAGE */
.message{
    text-align:center;
    color:green;
    margin-bottom:10px;
}

/* FORM */
input, textarea, select{
    width:100%;
    padding:14px;
    margin:10px 0;
    border-radius:10px;
    border:1px solid #e6d98c;
    font-size:15px;
    background:#fffef5;
}

textarea{
    min-height:120px;
}

/* IMAGE */
img{
    width:100%;
    max-height:300px;
    object-fit:cover;
    border-radius:12px;
    margin-bottom:10px;
}

/* BUTTON */
button{
    width:100%;
    padding:14px;
    border:none;
    border-radius:10px;
    font-size:15px;
    cursor:pointer;
    margin-top:10px;
}

.update{
    background:#FFD700;
    color:#333;
}

.update:hover{
    background:#f1c40f;
}

.delete{
    background:#f4b183;
    color:white;
}

.delete:hover{
    background:#e69138;
}

/* BACK */
.back{
    display:block;
    text-align:center;
    margin-top:15px;
    color:#8B8000;
    text-decoration:none;
}
</style>
</head>

<body>

<div class="container">

<div class="card">

<h2>Edit Buku</h2>

<p class="message"><?= $message ?></p>

<!-- FOTO -->
<?php if(!empty($buku['foto'])): ?>
    <img src="upload/<?= $buku['foto'] ?>">
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">

    <input type="text" name="judul" value="<?= $buku['judul'] ?>" required>

    <input type="text" name="penulis" value="<?= $buku['penulis'] ?>" required>

    <textarea name="deskripsi"><?= $buku['deskripsi'] ?></textarea>

    <input type="number" name="stok" value="<?= $buku['stok'] ?>" required>

    <select name="kategori">
        <option <?= $buku['kategori']=="Novel"?"selected":"" ?>>Novel</option>
        <option <?= $buku['kategori']=="Komik"?"selected":"" ?>>Komik</option>
        <option <?= $buku['kategori']=="Pendidikan"?"selected":"" ?>>Pendidikan</option>
        <option <?= $buku['kategori']=="Sejarah"?"selected":"" ?>>Sejarah</option>
        <option <?= $buku['kategori']=="Teknologi"?"selected":"" ?>>Teknologi</option>
        <option <?= $buku['kategori']=="Agama"?"selected":"" ?>>Agama</option>
    </select>

    <input type="file" name="foto">

    <button class="update" name="update">Update Buku</button>

</form>
<form method="POST" action="hapus_buku.php" onsubmit="return confirm('Yakin mau hapus buku ini?')">
    <input type="hidden" name="id" value="<?= $buku['id_buku'] ?>">
    <button class="delete">Hapus Buku</button>
</form>

<a class="back" href="dashboard_admin.php">← Kembali ke Dashboard</a>

</div>

</div>

</body>
</html>