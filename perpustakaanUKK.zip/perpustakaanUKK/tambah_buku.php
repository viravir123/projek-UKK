<?php
session_start();
include "service/database.php";

$message = "";

if(isset($_POST['tambah'])){

    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $deskripsi = $_POST['deskripsi'];
    $stok = $_POST['stok'];
    $kategori = $_POST['kategori'];

    $nama_file = $_FILES['foto']['name'];
    $tmp_file = $_FILES['foto']['tmp_name'];

    $folder = "upload/";
    $path = $folder . basename($nama_file);

    if(empty($judul) || empty($penulis)){
        $message = "Judul dan penulis wajib diisi";
    } else {

        if(!empty($nama_file)){

            if(move_uploaded_file($tmp_file, $path)){

                $sql = "INSERT INTO buku 
                (judul, penulis, deskripsi, stok, foto, kategori) 
                VALUES 
                ('$judul','$penulis','$deskripsi','$stok','$nama_file','$kategori')";

                $db->query($sql);
                $message = "Buku + foto berhasil ditambahkan";

            } else {
                $message = "Upload gambar gagal";
            }

        } else {

            $sql = "INSERT INTO buku 
            (judul, penulis, deskripsi, stok, kategori) 
            VALUES 
            ('$judul','$penulis','$deskripsi','$stok','$kategori')";

            $db->query($sql);
            $message = "Buku berhasil ditambahkan";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Tambah Buku</title>

<style>
<style>
body{
    margin:0;
    font-family:'Segoe UI', sans-serif;
    background:#FFFACD; /* Lemon Chiffon */
}

/* CENTER BOX */
.container{
    display:flex;
    justify-content:center;
    align-items:center;
    min-height:100vh;
}

/* CARD */
.card{
    background:#FFF8DC; /* Light Yellow (Cornsilk, masih satu tone) */
    padding:30px;
    width:420px;
    border-radius:15px;
    box-shadow:0 10px 30px rgba(0,0,0,0.15);
}

h2{
    text-align:center;
    color:#8B8000; /* kuning gelap biar kontras */
    margin-bottom:15px;
}

/* INPUT */
input, textarea, select{
    width:100%;
    padding:10px;
    margin-top:8px;
    margin-bottom:15px;
    border-radius:8px;
    border:1px solid #e6d98c;
    font-size:14px;
    background:#fffef5;
}

textarea{
    resize:none;
    height:80px;
}

/* BUTTON */
button{
    width:100%;
    padding:12px;
    background:#FFD700; /* gold / yellow */
    color:#333;
    border:none;
    border-radius:8px;
    font-weight:bold;
    cursor:pointer;
}

button:hover{
    background:#f1c40f;
}

/* MESSAGE */
.message{
    text-align:center;
    margin-bottom:10px;
    font-size:14px;
    color:#555;
}

/* BACK LINK */
a{
    display:block;
    text-align:center;
    margin-top:10px;
    text-decoration:none;
    color:#8B8000;
}
</style>

</style>
</head>

<body>

<div class="container">
    <div class="card">

        <h2>Tambah Buku</h2>

        <div class="message">
            <?= $message ?>
        </div>

        <form method="POST" enctype="multipart/form-data">

            <input type="text" name="judul" placeholder="Judul Buku" required>

            <input type="text" name="penulis" placeholder="Penulis" required>

            <textarea name="deskripsi" placeholder="Deskripsi"></textarea>

            <input type="number" name="stok" value="5" placeholder="Stok" required>

            <select name="kategori" required>
                <option value="">-- Pilih Kategori --</option>
                <option>Novel</option>
                <option>Komik</option>
                <option>Pendidikan</option>
                <option>Sejarah</option>
                <option>Teknologi</option>
                <option>Agama</option>
            </select>

            <input type="file" name="foto">

            <button type="submit" name="tambah">+ Tambah Buku</button>

        </form>

        <a href="dashboard_admin.php">← Kembali ke Dashboard</a>

    </div>
</div>

</body>
</html>