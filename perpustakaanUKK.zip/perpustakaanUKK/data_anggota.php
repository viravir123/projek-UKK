<?php
session_start();
include "service/database.php";

if(!isset($_SESSION["is_login"])){
    header("location: index.php");
    exit();
}

// hapus anggota
if(isset($_GET['hapus'])){
    $id = $_GET['hapus'];
    $db->query("DELETE FROM user WHERE id_user='$id'");
    header("location: data_anggota.php");
    exit();
}

// data anggota
$anggota = [];

// ambil input pencarian
$cari = $_GET['cari'] ?? '';

if(!empty($cari)){
    $cari = $db->real_escape_string($cari);
    $sql = "SELECT * FROM user 
            WHERE nama_lengkap LIKE '%$cari%' 
            OR no_hp LIKE '%$cari%' 
            OR gmail LIKE '%$cari%' 
            ORDER BY id_user DESC";
} else {
    $sql = "SELECT * FROM user ORDER BY id_user DESC";
}

$result = $db->query($sql);

if($result){
    while($row = $result->fetch_assoc()){
        $anggota[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Data Anggota</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', sans-serif;
    background:#FFFACD;
}

/* HEADER */
.header{
    background:#FFF8DC;
    color:#8B8000;
    padding:15px 25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 2px 8px rgba(0,0,0,0.08);
}

.header a{
    color:#333;
    text-decoration:none;
    background:#FFD700;
    padding:8px 12px;
    border-radius:8px;
}

/* CONTAINER */
.container{
    padding:25px;
}

/* TABLE BOX */
.table-box{
    background:#FFF8DC;
    padding:20px;
    border-radius:15px;
    box-shadow:0 10px 25px rgba(0,0,0,0.1);
    overflow-x:auto;
}

/* TABLE */
table{
    width:100%;
    border-collapse:collapse;
}

th{
    background:#FFD700;
    color:#333;
    padding:12px;
}

td{
    padding:12px;
    text-align:center;
    border-bottom:1px solid #eee;
}

/* HOVER */
tr:hover{
    background:#fff9e6;
}

/* BUTTON */
.btn-edit{
    background:#3498db;
    color:white;
    padding:6px 10px;
    border-radius:6px;
    text-decoration:none;
    font-size:12px;
    margin-right:5px;
}

.btn-hapus{
    background:#f4b183;
    color:white;
    padding:6px 10px;
    border-radius:6px;
    text-decoration:none;
    font-size:12px;
}

.btn-hapus:hover{
    background:#e69138;
}

.empty{
    text-align:center;
    padding:20px;
    color:#777;
}
</style>
</head>

<body>

<div class="header">
    <h3>Data Anggota</h3>
    <a href="dashboard_admin.php">← Kembali</a>
</div>

<div class="container">
<div class="table-box">

<!-- SEARCH -->
<form method="GET" style="margin-bottom:15px; display:flex; gap:10px;">
    <input type="text" name="cari" placeholder="Cari nama / email / no hp..."
           value="<?= $_GET['cari'] ?? '' ?>"
           style="padding:10px; width:250px; border-radius:8px; border:1px solid #ccc;">

    <button type="submit" style="padding:10px 15px; border:none; border-radius:8px; background:#3498db; color:white;">
        Cari
    </button>

    <a href="data_anggota.php" style="padding:10px 15px; background:#aaa; color:white; border-radius:8px; text-decoration:none;">
        Reset
    </a>
</form>

<?php if(count($anggota) > 0): ?>

<table>
<tr>
    <th>No</th>
    <th>Nama Lengkap</th>
    <th>No HP</th>
    <th>Email</th>
    <th>Waktu Masuk</th>
    <th>Aksi</th>
</tr>

<?php $no = 1; ?>
<?php foreach($anggota as $item): ?>
<tr>
    <td><?= $no++ ?></td>
    <td><?= $item["nama_lengkap"] ?></td>
    <td><?= $item["no_hp"] ?></td>
    <td><?= $item["gmail"] ?></td>

    <td>
        <?= !empty($item['created_at']) 
            ? date('d-m-Y H:i', strtotime($item['created_at'])) 
            : '-' ?>
    </td>

    <td>
        <a class="btn-edit" href="edit_anggota.php?id=<?= $item['id_user'] ?>">
            Edit
        </a>

        <a class="btn-hapus"
           href="data_anggota.php?hapus=<?= $item['id_user'] ?>"
           onclick="return confirm('Yakin mau hapus akun ini?')">
           Hapus
        </a>
    </td>
</tr>
<?php endforeach; ?>

</table>

<?php else: ?>
<div class="empty">Belum ada data anggota</div>
<?php endif; ?>

</div>
</div>

</body>
</html>