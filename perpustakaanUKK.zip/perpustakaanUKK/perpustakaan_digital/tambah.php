<?php
include 'koneksi.php';
if (isset($_POST['simpan'])) {
  mysqli_query($conn, "INSERT INTO buku VALUES (
    '',
    '$_POST[judul]',
    '$_POST[penulis]',
    '$_POST[penerbit]',
    '$_POST[tahun]'
  )");
  header("location:index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Tambah Buku</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<div class="container">
  <div class="sidebar">
    <h2>perpustakaan digital</h2>
    <a href="index.php">Data Buku</a>
  </div>

  <div class="content">
    <div class="card">
      <h2>Tambah Buku</h2><br>
      <form method="post">
        <input name="judul" placeholder="Judul Buku">
        <input name="penulis" placeholder="Penulis">
        <input name="penerbit" placeholder="Penerbit">
        <input name="tahun" type="number" placeholder="Tahun">
        <button name="simpan">Simpan</button>
      </form>
    </div>
  </div>
</div>

</body>
</html>
