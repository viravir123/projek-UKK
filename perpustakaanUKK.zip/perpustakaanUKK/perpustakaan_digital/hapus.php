<?php
include 'koneksi.php';
mysqli_query($conn, "DELETE FROM buku WHERE id='$_GET[id]'");
header("location:index.php");
