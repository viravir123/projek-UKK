<?php
include "koneksi.php";

$q_pinjam = mysqli_query($conn,"SELECT COUNT(*) AS total FROM transaksi WHERE status='pinjam'");
$q_selesai = mysqli_query($conn,"SELECT COUNT(*) AS total FROM transaksi WHERE status='kembali'");

$pinjam = $q_pinjam ? mysqli_fetch_assoc($q_pinjam) : ['total'=>0];
$selesai = $q_selesai ? mysqli_fetch_assoc($q_selesai) : ['total'=>0];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Transaksi</title>

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:Segoe UI}
body{background:radial-gradient(circle at top,#0b1d3a,#020617);color:white}
.layout{display:flex;min-height:100vh}
.sidebar{width:240px;background:rgba(0,0,0,.4);padding:20px}
.sidebar a{display:block;padding:12px;border-radius:10px;color:#cbd5e1;text-decoration:none;margin-bottom:8px}
.sidebar a:hover,.active{background:rgba(255,255,255,.1)}
.logout{color:#f87171}
.main{flex:1;padding:40px}

.stats{
 display:grid;
 grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
 gap:20px;margin-top:30px
}
.stat{
 background:rgba(255,255,255,.06);
 padding:30px;
 border-radius:18px;
 cursor:pointer;
 transition:.2s
}
.stat:hover{
 background:rgba(255,255,255,.12);
 transform:translateY(-5px)
}
.stat b{font-size:32px}
</style>
</head>

<body>
<div class="layout">

<aside class="sidebar">
  <h2>Perpustakaan</h2>
  <a href="dashboard.php">Dashboard</a>
  <a href="databuku.php">Data Buku</a>
  <a href="dataanggota.php">Data Anggota</a>
  <a href="transaksi.php" class="active">Transaksi</a>
  <a href="index.html" class="logout">Keluar</a>
</aside>

<main class="main">
<h1>Transaksi Peminjaman</h1>
<p>Kelola peminjaman & pengembalian</p>

<div class="stats">
  <div class="stat" onclick="location.href='transaksi_pinjam.php'">
    <h3>📘 Peminjaman Buku</h3>
    <p>Tambah transaksi</p>
  </div>

  <div class="stat" onclick="location.href='transaksi_kembali.php'">
    <h3>📗 Pengembalian Buku</h3>
    <p>Proses pengembalian</p>
  </div>

  <div class="stat">
    <h3>⏳ Sedang Dipinjam</h3>
    <b><?= $pinjam['total'] ?></b>
  </div>

  <div class="stat">
    <h3>✅ Selesai</h3>
    <b><?= $selesai['total'] ?></b>
  </div>
</div>

</main>
</div>
</body>
</html>
