<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Login Admin</title>

<style>
body{
  background:radial-gradient(circle at top,#0b1d3a,#020617);
  font-family:"Segoe UI",sans-serif;
  display:flex;
  justify-content:center;
  align-items:center;
  height:100vh;
  color:white;
}

.login-box{
  width:360px;
  background:rgba(15,23,42,.75);
  padding:30px;
  border-radius:18px;
  border:1px solid rgba(255,255,255,.1);
}

.login-box h2{
  text-align:center;
  margin-bottom:25px;
}

input{
  width:100%;
  padding:12px;
  margin-bottom:15px;
  border:none;
  border-radius:8px;
  background:#020617;
  color:white;
}

button{
  width:100%;
  padding:12px;
  background:linear-gradient(135deg,#6366f1,#3b82f6);
  border:none;
  border-radius:8px;
  color:white;
  font-size:15px;
  cursor:pointer;
}

button:hover{
  opacity:.9;
}

.back{
  text-align:center;
  margin-top:15px;
  font-size:14px;
}
</style>
</head>

<body>

<div class="login-box">
  <h2>Login Admin</h2>

  <form action="proses_login_admin.php" method="POST">
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <button type="submit">Login</button>
  </form>

  <div class="back">
    <a href="index.html" style="color:#93c5fd;">← Kembali ke Landing Page</a>
  </div>
</div>

</body>
</html>
