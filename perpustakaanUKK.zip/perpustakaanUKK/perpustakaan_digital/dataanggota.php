<?php
include "koneksi.php";
$query = mysqli_query($conn, "SELECT * FROM buku");
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Data anggota</title>

<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:"Segoe UI",sans-serif;}
body{background:radial-gradient(circle at top,#0b1d3a,#020617);color:white}

.layout{display:flex;min-height:100vh}
.sidebar{width:240px;background:rgba(0,0,0,.4);padding:20px}
.sidebar a{
  display:block;padding:12px;border-radius:10px;
  color:#cbd5e1;text-decoration:none;margin-bottom:8px
}
.sidebar a:hover,.active{background:rgba(255,255,255,.1)}
.logout{color:#f87171;margin-top:40px}

.main{flex:1;padding:40px}
table{width:100%;border-collapse:collapse;margin-top:20px}
th,td{padding:12px;border-bottom:1px solid rgba(255,255,255,.1)}
.btn{background:#6366f1;border:none;color:white;padding:8px 14px;border-radius:8px}
</style>
</head>

<body>

<div class="layout">

<aside class="sidebar">
  <h2>Perpustakaan</h2>
  <a href="dashboard.html">Dashboard</a>
  <a href="databuku.php" class="active">Data Buku</a>
  <a href="#">Data Anggota</a>
  <a href="#">Transaksi</a>
  <a class="logout" href="index.html">Keluar</a>
</aside>

<main class="main">
  <h1>Data anggota</h1>

  <table>
    <tr>
      <th>nama lengkap</th>
      <th>kelas</th>
      <th>tempat lahir</th>
      <th>tanggal lahir</th>
      <th>alamat</th>
      <th>no telepon</th>
      <th>Aksi</th>
    </tr>

    <?php while($row = mysqli_fetch_assoc($query)){ ?>
    <tr>
      <td><?= $row['judul'] ?></td>
      <td><?= $row['penulis'] ?></td>
      <td><?= $row['kategori'] ?></td>
      <td><?= $row['stok'] ?></td>
      <td>
        
      </td>
    </tr>
    <?php } ?>
  </table>
</main>

</div>

</body>
</html>
