<?php
session_start();
if(!isset($_SESSION['admin'])){
  header("Location: login_admin.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Dashboard Admin</title>
<style>
body{
  font-family:Segoe UI;
  background:#020617;
  color:white;
  padding:30px;
}
a{color:#60a5fa;text-decoration:none}
</style>
</head>

<body>

<h1>Dashboard Admin</h1>
<p>Selamat datang, <b><?= $_SESSION['admin']; ?></b></p>

<ul>
  <li>Kelola Buku</li>
  <li>Kelola Anggota</li>
  <li>Transaksi Peminjaman</li>
</ul>

<br>
<a href="logout.php">Logout</a>

</body>
</html>
