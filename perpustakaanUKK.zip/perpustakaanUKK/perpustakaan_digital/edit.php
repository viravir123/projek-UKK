<?php
include 'koneksi.php';
$id = $_GET['id'];
$b = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM buku WHERE id='$id'"));

if (isset($_POST['update'])) {
  mysqli_query($conn, "UPDATE buku SET
    judul='$_POST[judul]',
    penulis='$_POST[penulis]',
    penerbit='$_POST[penerbit]',
    tahun='$_POST[tahun]'
    WHERE id='$id'
  ");
  header("location:index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Edit Buku</title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>

<div class="container">
  <div class="sidebar">
    <h2>perpustakaan digital</h2>
    <a href="index.php">Data Buku</a>
  </div>

  <div class="content">
    <div class="card">
      <h2>Edit Buku</h2><br>
      <form method="post">
        <input name="judul" value="<?= $b['judul'] ?>">
        <input name="penulis" value="<?= $b['penulis'] ?>">
        <input name="penerbit" value="<?= $b['penerbit'] ?>">
        <input name="tahun" type="number" value="<?= $b['tahun'] ?>">
        <button name="update">Update</button>
      </form>
    </div>
  </div>
</div>

</body>
</html>
