<?php
session_start();
include "service/database.php";

$login_message = "";

// kalau sudah login
if(isset($_SESSION["is_login"])){
    if($_SESSION["role"] == "admin"){
        header("location: dashboard_admin.php");
    } else {
        header("location: dashboard.php");
    }
    exit();
}

if(isset($_POST['login'])){

    $role = $_POST['role'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    if(empty($role) || empty($username) || empty($password)){
        $login_message = "Semua data wajib diisi!";
    } else {

        if($role == "admin"){
            $sql = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
            $result = $db->query($sql);

            if($result && $result->num_rows > 0){
                $data = $result->fetch_assoc();

                $_SESSION["is_login"] = true;
                $_SESSION["role"] = "admin";
                $_SESSION["username"] = $data["username"];
                $_SESSION["id_user"] = $data["id_admin"];

                header("location: dashboard_admin.php");
                exit();
            } else {
                $login_message = "Admin tidak ditemukan!";
            }
        }

        else if($role == "user"){
            $sql = "SELECT * FROM user WHERE nama_lengkap='$username'";
            $result = $db->query($sql);

            if($result && $result->num_rows > 0){
                $data = $result->fetch_assoc();

                if(password_verify($password, $data['password'])){
                    $_SESSION["is_login"] = true;
                    $_SESSION["role"] = "user";
                    $_SESSION["id_user"] = $data["id_user"];
                    $_SESSION["nama_lengkap"] = $data["nama_lengkap"];

                    header("location: dashboard.php");
                    exit();
                } else {
                    $login_message = "Password salah!";
                }
            } else {
                $login_message = "User tidak ditemukan!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Login Perpustakaan</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

/* 🌼 BACKGROUND */
body{
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background: linear-gradient(135deg, #FFFFE0, #FFFACD);
}

/* 🔥 BOX */
.box{
    width:500px;
    padding:55px;
    border-radius:22px;
    text-align:center;

    background: rgba(255,255,255,0.8);
    backdrop-filter: blur(10px);

    box-shadow:0 15px 35px rgba(0,0,0,0.2);
}

/* TITLE */
.title{
    font-size:28px;
    font-weight:bold;
    color:#b8860b;
    margin-bottom:10px;
}

/* MESSAGE */
.message{
    font-size:13px;
    color:#e74c3c;
    margin-bottom:10px;
}

/* INPUT */
select, input{
    width:100%;
    padding:14px;
    margin-top:14px;
    border:1px solid #ddd;
    border-radius:10px;
    outline:none;
    font-size:14px;
    transition:0.3s;
}

select:focus, input:focus{
    border-color:#f4b400;
    box-shadow:0 0 8px rgba(244,180,0,0.4);
}

/* BUTTON */
button{
    width:100%;
    padding:14px;
    margin-top:18px;
    background:#f4b400;
    color:white;
    border:none;
    border-radius:10px;
    cursor:pointer;
    font-size:15px;
    transition:0.3s;
}

button:hover{
    background:#e09e00;
    transform:scale(1.03);
}

/* FOOTER */
.footer{
    margin-top:18px;
    font-size:12px;
    color:#777;
}
</style>
</head>

<body>

<div class="box">

    <div class="title">Login Perpustakaan</div>

    <div class="message"><?= $login_message ?></div>

    <form method="POST">

        <select name="role" required>
            <option value="">-- Login sebagai --</option>
            <option value="admin">Admin</option>
            <option value="user">User</option>
        </select>

        <input type="text" name="username" placeholder="Username / Nama Lengkap" required>

        <input type="password" name="password" placeholder="Password" required>

        <button type="submit" name="login">Masuk</button>

    </form>
    <a href="register.php">belum punya akun? register</a>

    <div class="footer">
        Sistem Perpustakaan Digital © 2026
    </div>

</div>

</body>
</html>