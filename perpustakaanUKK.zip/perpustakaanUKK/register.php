<?php
include "service/database.php";
session_start();

$register_message = "";

// kalau sudah login
if(isset($_SESSION["is_login"])){
    header("location: dashboard.php");
    exit();
}

if(isset($_POST["register"])){

    $nama_lengkap = $_POST['nama_lengkap'];
    $no_hp = $_POST['no_hp'];
    $gmail = $_POST['gmail'];
    $password = $_POST['password'];

    if(empty($nama_lengkap) || empty($no_hp) || empty($gmail) || empty($password)){
        $register_message = "Semua data wajib diisi!";
    } else {

        $hash_password = password_hash($password, PASSWORD_DEFAULT);

        try {
            $sql = "INSERT INTO user (nama_lengkap, no_hp, gmail, password) 
                    VALUES ('$nama_lengkap','$no_hp','$gmail','$hash_password')";

            if($db->query($sql)){
                $register_message = "Register berhasil, silakan login!";
            } else {
                $register_message = "Gagal register: " . $db->error;
            }

        } catch (mysqli_sql_exception $e) {
            $register_message = "Email / data sudah digunakan!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Register Perpustakaan</title>

    <style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background: #FFFACD; /* lemon chiffon */
}

.box {
    width: 450px; /* diperbesar */
    background: #FFF8DC; /* light yellow */
    padding: 40px; /* lebih lega */
    border-radius: 18px;
    box-shadow: 0 15px 35px rgba(0,0,0,0.15);
    text-align: center;
}

.title {
    font-size: 24px;
    font-weight: bold;
    color: #8B8000;
    margin-bottom: 15px;
}

.msg {
    font-size: 13px;
    color: red;
    margin-bottom: 10px;
}

input {
    width: 100%;
    padding: 13px;
    margin-top: 12px;
    border: 1px solid #e6d98c;
    border-radius: 8px;
    outline: none;
    transition: 0.3s;
    background: #fffef5;
}

input:focus {
    border-color: #FFD700;
    box-shadow: 0 0 5px #FFD700;
}

button {
    width: 100%;
    padding: 13px;
    margin-top: 15px;
    background: #FFD700;
    color: #333;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    font-size: 15px;
    transition: 0.3s;
}

button:hover {
    background: #f1c40f;
}

a {
    display: block;
    margin-top: 12px;
    font-size: 13px;
    color: #8B8000;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

.footer {
    margin-top: 15px;
    font-size: 12px;
    color: #777;
}
</style>
</head>

<body>

<div class="box">

    <div class="title">Daftar Akun</div>

    <div class="msg"><?= $register_message ?></div>

    <form method="POST">

        <input type="text" name="nama_lengkap" placeholder="Nama Lengkap" required>

        <input type="text" name="no_hp" placeholder="No HP" required>

        <input type="email" name="gmail" placeholder="Email" required>

        <input type="password" name="password" placeholder="Password" required>

        <button type="submit" name="register">Daftar Sekarang</button>

    </form>

    <a href="login.php">Sudah punya akun? Login</a>

    <div class="footer">
        Sistem Perpustakaan Digital © 2026
    </div>

</div>

</body>
</html>