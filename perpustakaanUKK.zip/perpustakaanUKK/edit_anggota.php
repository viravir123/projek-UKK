<?php
session_start();
include "service/database.php";

if(!isset($_SESSION["is_login"])){
    header("location: index.php");
    exit();
}

$id = $_GET['id'] ?? '';
$id = $db->real_escape_string($id);

$data = $db->query("SELECT * FROM user WHERE id_user='$id'")->fetch_assoc();

if(isset($_POST['update'])){
    $nama = $_POST['nama_lengkap'];
    $hp = $_POST['no_hp'];
    $gmail = $_POST['gmail'];

    $db->query("UPDATE user SET 
        nama_lengkap='$nama',
        no_hp='$hp',
        gmail='$gmail'
        WHERE id_user='$id'
    ");

    header("location: data_anggota.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Edit Anggota</title>

<style>
body{
    margin:0;
    font-family:'Segoe UI', sans-serif;
    background:#FFFACD;
}

/* HEADER */
.header{
    background:#FFF8DC;
    color:#8B8000;
    padding:15px 25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 2px 8px rgba(0,0,0,0.08);
}

.header a{
    text-decoration:none;
    background:#FFD700;
    padding:8px 12px;
    border-radius:8px;
    color:#333;
}

/* FORM BOX */
.container{
    display:flex;
    justify-content:center;
    align-items:center;
    height:80vh;
}

.form-box{
    background:#FFF8DC;
    padding:30px;
    border-radius:15px;
    width:350px;
    box-shadow:0 10px 25px rgba(0,0,0,0.1);
}

.form-box h2{
    text-align:center;
    margin-bottom:20px;
    color:#555;
}

/* INPUT */
.form-box input{
    width:100%;
    padding:10px;
    margin-bottom:15px;
    border-radius:8px;
    border:1px solid #ccc;
}

/* BUTTON */
.btn{
    width:100%;
    padding:10px;
    border:none;
    border-radius:8px;
    background:#3498db;
    color:white;
    font-size:14px;
    cursor:pointer;
}

.btn:hover{
    background:#2980b9;
}
</style>

</head>

<body>

<div class="header">
    <h3>Edit Anggota</h3>
    <a href="data_anggota.php">← Kembali</a>
</div>

<div class="container">

<div class="form-box">
    <h2>Update Data</h2>

    <form method="POST">
        <input type="text" name="nama_lengkap" 
               value="<?= $data['nama_lengkap'] ?>" 
               placeholder="Nama Lengkap" required>

        <input type="text" name="no_hp" 
               value="<?= $data['no_hp'] ?>" 
               placeholder="No HP" required>

        <input type="email" name="gmail" 
               value="<?= $data['gmail'] ?>" 
               placeholder="Email" required>

        <button name="update" class="btn">Update</button>
    </form>
</div>

</div>

</body>
</html>