<?php
session_start();
include "service/database.php";

if(!isset($_SESSION["is_login"])){
    header("location: index.php");
    exit();
}

// ambil id
$id = $_POST['id'] ?? 0;

if($id == 0){
    die("ID tidak valid");
}

// hapus
if($db->query("DELETE FROM buku WHERE id_buku='$id'")){
    header("location: dashboard_admin.php");
    exit();
} else {
    die("Gagal hapus: " . $db->error);
}
