<?php
session_start();
include "service/database.php";

if(!isset($_SESSION["is_login"])){
    header("location: index.php");
    exit();
}

$id = $_GET['id'] ?? 0;

$sql = "SELECT * FROM buku WHERE id_buku='$id'";
$result = $db->query($sql);
$buku = $result->fetch_assoc();

$message = "";

if(isset($_POST['pinjam'])){

    $id_user = $_SESSION['id_user'] ?? null;

    if(!$id_user || !$id){
        $message = "Data tidak valid";
    } else {

        // cek apakah sudah pernah pinjam (yang masih aktif / dipinjam)
        $cek = $db->query("SELECT * FROM peminjaman 
                           WHERE id_user='$id_user' 
                           AND id_buku='$id' 
                           AND status IN ('pending','dipinjam')");

        if($cek && $cek->num_rows > 0){
            $message = "Kamu sudah mengajukan peminjaman buku ini";
        }
        else {

            // INSERT PENDING (MENUNGGU ADMIN)
            $db->query("
                INSERT INTO peminjaman 
                (id_user, id_buku, tanggal_pinjam, status)
                VALUES 
                ('$id_user','$id', NOW(), 'pending')
            ");

            $message = "Permintaan peminjaman dikirim, menunggu persetujuan admin";
        }
    }
}

// hapus buku (admin)
if(isset($_POST['hapus']) && $_SESSION['role'] == 'admin'){
    $db->query("DELETE FROM buku WHERE id_buku='$id'");
    header("location: dashboard_admin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Detail Buku</title>

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Segoe UI', sans-serif;
}

body{
    min-height:100vh;
    background:#FFFACD;
    display:flex;
    justify-content:center;
    align-items:center;
    padding:30px;
}

/* CARD */
.box{
    width:95%;
    max-width:1100px;
    background:#FFF8DC;
    border-radius:20px;
    padding:40px;
    display:flex;
    gap:30px;
    box-shadow:0 10px 25px rgba(0,0,0,0.1);
}

/* FOTO */
.box img{
    width:320px;
    height:420px;
    object-fit:cover;
    border-radius:15px;
}

/* CONTENT */
.content{
    flex:1;
}

h3{
    font-size:24px;
    color:#8B8000;
    margin-bottom:10px;
}

.msg{
    color:green;
    font-size:14px;
    margin-bottom:10px;
}

.judul{
    font-size:28px;
    font-weight:bold;
    color:#333;
    margin-bottom:10px;
}

.info{
    font-size:17px;
    margin:5px 0;
    color:#555;
}

.desc{
    margin-top:15px;
    font-size:17px;
    line-height:1.6;
    color:#666;
}

/* BUTTON */
button, a.btn{
    padding:12px 18px;
    border:none;
    border-radius:8px;
    cursor:pointer;
    font-size:14px;
    margin:6px 4px;
    text-decoration:none;
    transition:0.3s;
}

.pinjam{
    background:#FFD700;
    color:#333;
}
.pinjam:hover{
    background:#f1c40f;
}

.hapus{
    background:#f4b183;
    color:white;
}
.hapus:hover{
    background:#e69138;
}

.edit{
    background:#ffe599;
    color:#333;
}
.edit:hover{
    background:#f1c40f;
}

.back{
    background:#a9dfbf;
    color:#333;
}
.back:hover{
    background:#7dcea0;
}

/* MODAL */
.modal{
    display:none;
    position:fixed;
    top:0;left:0;
    width:100%;height:100%;
    background:rgba(0,0,0,0.5);
    justify-content:center;
    align-items:center;
}

.modal-box{
    background:#FFF8DC;
    padding:25px;
    border-radius:12px;
    width:320px;
    text-align:center;
}
</style>
</head>

<body>

<div class="box">

<?php if($buku): ?>

    <?php if(!empty($buku['foto'])): ?>
        <img src="upload/<?= $buku['foto'] ?>">
    <?php endif; ?>

    <div class="content">

        <h3>Detail Buku</h3>

        <div class="msg"><?= $message ?></div>

        <div class="judul"><?= $buku['judul'] ?></div>

        <div class="info">Penulis: <?= $buku['penulis'] ?></div>
        <div class="info">Kategori: <?= $buku['kategori'] ?></div>
        <div class="info">Stok: <?= $buku['stok'] ?></div>

        <div class="desc"><?= $buku['deskripsi'] ?></div>

        <hr>

        <?php if($_SESSION['role'] == 'admin'): ?>

            <a class="btn edit" href="edit_buku.php?id=<?= $buku['id_buku'] ?>">Edit</a>

            <form method="POST" style="display:inline;">
                <button class="hapus" name="hapus">Hapus</button>
            </form>

        <?php else: ?>

            <!-- USER PINJAM (PENDING) -->
            <button class="pinjam" onclick="openModal()">
                Pinjam Buku
            </button>

        <?php endif; ?>

        <br><br>

        <?php if($_SESSION['role'] == 'admin'): ?>
            <a class="btn back" href="dashboard_admin.php">Kembali</a>
        <?php else: ?>
            <a class="btn back" href="dashboard.php">Kembali</a>
        <?php endif; ?>

    </div>

<?php else: ?>
    <p>Buku tidak ditemukan</p>
<?php endif; ?>

</div>

<!-- MODAL -->
<div class="modal" id="modal">
    <div class="modal-box">
        <p>Yakin mau ajukan peminjaman buku ini?</p>

        <form method="POST">
            <button class="pinjam" name="pinjam">Ya Ajukan</button>
        </form>

        <br>

        <button onclick="closeModal()" class="back">Batal</button>
    </div>
</div>

<script>
function openModal(){
    document.getElementById("modal").style.display = "flex";
}

function closeModal(){
    document.getElementById("modal").style.display = "none";
}
</script>

</body>
</html>